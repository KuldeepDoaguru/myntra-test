import React from "react";

const Shop = () => {
  return (
    <>
      <h2>SHop</h2>
    </>
  );
};

export default Shop;
