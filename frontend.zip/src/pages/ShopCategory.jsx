import React from "react";

const ShopCategory = () => {
  return (
    <div>
      <h1>shop category</h1>
    </div>
  );
};

export default ShopCategory;
