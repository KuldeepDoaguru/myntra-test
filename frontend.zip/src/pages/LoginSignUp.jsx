import React from "react";

const LoginSignUp = () => {
  return (
    <div>
      <h1>Login Signup</h1>
    </div>
  );
};

export default LoginSignUp;
